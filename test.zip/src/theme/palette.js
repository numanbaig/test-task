/* eslint-disable import/no-anonymous-default-export */

const white = "#FFFFFF";
const black = "#e8ebe5";
export default {
  primary: {
    primary: "#21a390",
    main: white,
    secondary: "#f3f5f9",
    para: "#c0cada",
    label: "#b4c0d3",
    focus: "#280FA5",
    disable: "#6367E7",
    red: "red",
    dark: "#000",
  },

  white: "#FFFFFF",
};
