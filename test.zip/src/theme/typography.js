/* eslint-disable import/no-anonymous-default-export */
import palette from "./palette";

export default {
  fontFamily: '"Montserrat", sans-serif',
  fontStyle: "normal",
  fontWeight: "normal",
  color: "#000",
};
